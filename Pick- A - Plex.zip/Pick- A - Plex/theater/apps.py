from django.apps import AppConfig


class TheaterConfig(AppConfig):
    name = 'theater'
